package main

import (
	"testing"
)

func TestGetControllerInfo(t *testing.T) {
	getControllerInfo("testdata/router/")
}
