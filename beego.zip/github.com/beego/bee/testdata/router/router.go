package router

import (
	"github.com/astaxie/beego"
)

type Router struct {
	beego.Controller
}

func (r *Router) Get() {

}

func (r *Router) Post() {

}

type Controller struct {
}

func (c *Controller) Put() {

}

func (c *Controller) Delete() {

}
